# ALDIK EGGER + GRANDEX — safe staging installer for VS Code PowerShell
# Does NOT change application source code, database, prices, or deploy.
param(
    [string]$ProjectPath = 'C:\projects\ai-interior-saas',
    [string]$ArchivePath = ''
)
$ErrorActionPreference = 'Stop'
try {
    if (-not (Test-Path -LiteralPath $ProjectPath -PathType Container)) {
        throw "Project not found: $ProjectPath"
    }
    if (-not (Test-Path -LiteralPath (Join-Path $ProjectPath 'package.json') -PathType Leaf)) {
        throw "This does not look like ALDIK source: package.json missing in $ProjectPath"
    }
    if ([string]::IsNullOrWhiteSpace($ArchivePath)) {
        $fileName = 'ALDIK_EGGER_26_GRANDEX_FULL_REVIEW_PACK.zip'
        $candidates = @(
            (Join-Path (Get-Location).Path $fileName),
            (Join-Path $PSScriptRoot $fileName),
            (Join-Path $env:USERPROFILE "Downloads\$fileName"),
            (Join-Path $env:USERPROFILE "Desktop\$fileName")
        )
        $ArchivePath = $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
        if (-not $ArchivePath) {
            throw "Download $fileName to Downloads first, or supply -ArchivePath 'C:\path\$fileName'"
        }
    }
    $targetRoot = Join-Path $ProjectPath 'CATALOG_STAGING\99_IMPORT_QUEUE'
    New-Item -ItemType Directory -Path $targetRoot -Force | Out-Null
    $destination = Join-Path $targetRoot 'EGGER_GRANDEX'
    if (Test-Path -LiteralPath $destination) {
        # Never erase work a developer may have already started in this folder.
        throw "Destination already exists: $destination. No files were overwritten. Check folder manually first."
    }
    $stagingTemp = Join-Path $targetRoot ('_temp_egger_grandex_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stagingTemp | Out-Null
    try {
        Expand-Archive -LiteralPath $ArchivePath -DestinationPath $stagingTemp -ErrorAction Stop
        $jsonPath = Join-Path $stagingTemp 'data\COMBINED_EGGER_GRANDEX_REVIEW.json'
        if (-not (Test-Path -LiteralPath $jsonPath)) { throw 'Combined review JSON is missing from ZIP.' }
        $items = @(Get-Content -LiteralPath $jsonPath -Raw -Encoding UTF8 | ConvertFrom-Json)
        if ($items.Count -ne 397) { throw "Unexpected record count: $($items.Count), expected 397" }
        $byBrand = $items | Group-Object brand
        $brandCounts = @{}
        foreach ($g in $byBrand) { $brandCounts[$g.Name] = $g.Count }
        if ($brandCounts['EGGER'] -ne 307 -or $brandCounts['GRANDEX'] -ne 90) {
            throw "Unexpected brand counts: EGGER=$($brandCounts['EGGER']) GRANDEX=$($brandCounts['GRANDEX'])"
        }
        $missing = @()
        $badRefs = @()
        foreach ($item in $items) {
            $ref = [string]$item.preview
            if ($ref -notmatch '^assets/(EGGER|GRANDEX)/[A-Za-z0-9_./-]+$' -or $ref.Contains('..')) {
                $badRefs += "$($item.id): $ref"; continue
            }
            if (-not (Test-Path -LiteralPath (Join-Path $stagingTemp $ref))) { $missing += "$($item.id): $ref" }
        }
        if ($badRefs.Count -gt 0 -or $missing.Count -gt 0) {
            throw "Invalid paths $($badRefs.Count), missing previews $($missing.Count)"
        }
        Move-Item -LiteralPath $stagingTemp -Destination $destination
    } finally {
        if (Test-Path -LiteralPath $stagingTemp) { Remove-Item -LiteralPath $stagingTemp -Recurse -Force }
    }
    Write-Host ''
    Write-Host 'ALDIK EGGER + GRANDEX: SAFE STAGING READY' -ForegroundColor Green
    Write-Host "EGGER: $($brandCounts['EGGER']) reference records"
    Write-Host "GRANDEX: $($brandCounts['GRANDEX']) reference records"
    Write-Host "Folder: $destination"
    Write-Host 'Database changed: NO'
    Write-Host 'Application source changed: NO'
    Write-Host 'Production import: NO'
    Write-Host ''
    Write-Host 'Open the local preview from this folder:'
    Write-Host (Join-Path $destination 'index.html')
    Start-Process -FilePath (Join-Path $destination 'index.html')
    Write-Host ''
    Write-Host 'NEXT: Paste the Claude Code instruction from ALDIK_CATALOG_NEXT_STEP_FOR_CLAUDE.md'
} catch {
    Write-Host "SETUP STOPPED: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
