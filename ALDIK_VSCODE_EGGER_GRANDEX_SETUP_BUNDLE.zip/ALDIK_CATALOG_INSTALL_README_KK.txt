ALDIK Studio — EGGER + GRANDEX (VS Code)

1) ALDIK_VSCODE_EGGER_GRANDEX_SETUP_BUNDLE.zip файлын Downloads папкасына жүкте.
2) VS Code → Terminal → PowerShell ішіне осы 3 жолды енгіз:

$bundle = "$env:USERPROFILE\Downloads\ALDIK_VSCODE_EGGER_GRANDEX_SETUP_BUNDLE.zip"
Expand-Archive -LiteralPath $bundle -DestinationPath "$env:TEMP\aldik_catalog_eg" -Force
& "$env:TEMP\aldik_catalog_eg\ALDIK_EGGER_GRANDEX_VSCODE_SETUP.ps1"

Егер execution policy рұқсат бермесе, үшінші жолдың орнына:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$env:TEMP\aldik_catalog_eg\ALDIK_EGGER_GRANDEX_VSCODE_SETUP.ps1"

Нәтиже: каталог жобаның CATALOG_STAGING/99_IMPORT_QUEUE/EGGER_GRANDEX ішіне түседі;
EGGER 307 + GRANDEX 90 жазба және суреттері тексеріледі, preview браузерде ашылады.
Бұл INSTALL тек staging-ке қояды. /admin/catalog және 3D әлі автоматты өзгермейді.

3) Claude Code-қа ALDIK_CATALOG_NEXT_STEP_FOR_CLAUDE.md файлын бер.
Алдымен dry-run / audit, кейін рұқсатпен test organization / actual integration.

Қауіпсіздік: production database, файлдардың түпнұсқалары, бағалар және source code өзгермейді.
