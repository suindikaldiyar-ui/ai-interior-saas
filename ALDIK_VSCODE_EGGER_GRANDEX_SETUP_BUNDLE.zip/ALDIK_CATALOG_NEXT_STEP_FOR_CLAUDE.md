# ALDIK Studio — EGGER 26+ + GRANDEX import/integration

## START CATALOG-EG-01 (bounded slice; no production writes)

Continue the current local Next.js repo. Inspect `CLAUDE.md`, the actual current catalog components, `/admin/catalog` UI and routes, current organization catalog records and 3D material selection path.

Source assets were safely staged at:
`CATALOG_STAGING/99_IMPORT_QUEUE/EGGER_GRANDEX/`

Read these exact files:
- `README_KK_AND_EN.md`
- `data/COMBINED_EGGER_GRANDEX_REVIEW.json`
- `data/EGGER_NAMES_NOT_IN_BROCHURE_FOR_OFFICIAL_VERIFICATION.csv`
- `guide/CLAUDE_SAFE_IMPORT_PROMPT.md`

### Required behavior

1. Determine the actual org-scoped material schemas and existing EGGER/GRANDEX entries. Do not assume the 397 review records are 397 unique saleable SKUs. Source is a PDF overview, with 307 EGGER card records (268 code+surface unique combinations) and 90 GRANDEX cards. Some EGGER names are missing. Import labels must not misrepresent those as verified.
2. Build an idempotent preview/dry-run importer that maps manufacturer + code + finish + application and detects collisions, pre-existing items, rights and unknown prices. Show a readable `new / duplicate / conflicting / incomplete / ineligible` summary. Do not mutate production records. Do not change prices, category IDs or other organizations.
3. On a test organization, after explicitly showing what would change, implement a manufacturer-filtered attractive materials browser with local reference swatches, verified name labels or `name unavailable`, and explicit `REFERENCE ONLY` where applicable. Preview may not be commercially published before confirming image rights.
4. Preserve critical category distinction: EGGER furniture board, PerfectSense, EGGER worktop *versus* GRANDEX acrylic solid surface. Do not apply any material to an incompatible physical part. Board ≠ solid stone.
5. Connect chosen EGGER material to carcass / facade / shelves through the **existing** canonical `MillworkState` material references, and GRANDEX to the existing worktop material path; no duplicate state, no new 3D furniture engine. Material change must not mutate cut dimensions or drilling.
6. If there is no authorized full-board PBR/texture image, render honest solid-color or clearly marked reference preview only, never repeat a tiny PDF swatch as a realistic seamless wood texture. Preserve current renderer stability. Prevent facade transparency in normal design mode, but leave manufacturing layer visibility as separate feature.
7. Ensure prices remain null or visibly `UNPRICED` if unspecified. Existing organization price remains unchanged; quotations with unpriced items cannot be represented as final verified quotations.
8. Acceptance: unit tests for idempotence and collisions; typecheck and build; real browser path: `/admin/catalog` → EGGER/GRANDEX → Studio bedroom wardrobe material → 3D; check quote BOM and persistent reload; take screenshots. Test GRANDEX on a worktop if available and report `BLOCKED` if kitchen/worktop path is not yet enabled.

### Hard safety rules

- First make an audit/dry-run, then report and **STOP** before actual production import.
- Never modify `MANUFACTURER_CATALOGS/**/raw/`, KIRA, or supplier originals.
- Never overwrite an existing product, price, image or supplier price without approved, explicit mapping.
- No production DB writes; only temporary test org, if test environment permits.
- No commit, push, deploy.
- Status `DONE / PARTIAL / BLOCKED` with counts, tests, source/code paths and screenshots. Distinguish PDF reference assets from real approved full-board textures.
